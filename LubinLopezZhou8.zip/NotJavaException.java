
//-----------------------------------------------------------------
// Author(s): Daniel Lubin , Gabriel Lopez, Calvin Zhou 
// Date of Last Modification: 12/8/2022
// Course: CS111B 
// Instructor: C. Conner 
// Assignment #8
// File Name: NotJavaException.java
// An exeptipn class for JavaOrNot.java.
//-----------------------------------------------------------------
public class NotJavaException extends Exception
{
    /* Passing message through class constructor */
    public NotJavaException(String message){
        super(message);
    }   
}