/*Algorithm
 * 1. Create new file for storing the output 
 * 2.Find all files the the extension ".java" 
 * 3.Print the name of ".java" files in the output file.
 * 4.Return a closing message for the user.
 */
//-----------------------------------------------------------------
// Author(s): Daniel Lubin , Gabriel Lopez, Calvin Zhou 
// Date of Last Modification: 12/8/2022
// Course: CS111B 
// Instructor: C. Conner 
// Assignment #8
// File Name: JavaOrNot.java
// A program that finds all files that dont end in ".java" and places them in a text file.
//-----------------------------------------------------------------
import java.io.*;

public class JavaOrNot 
{
    public static void main(String [] args)
    {
         File folder = new File(".");  //dot is current directory
         File[] listOfFiles = folder.listFiles(); //we now have array of File objects
         String name = "";
         String outputFile = "nonJava.txt";

         /* Begin try block to test files */
         try {
            /* Creates a new file for the output */
            PrintWriter outFile = new PrintWriter(new File(outputFile));
            
            /* For each file in the directory... */
            for (File file : listOfFiles){
                try {
                    /* Check it's a file not subdirectory */
                    if (file.isFile()){
                        name = file.getName(); //each file name is a String
                        System.out.println(name);

                    /* Checks if the extension ends in ".java" */
                    if(!name.endsWith(".java"))
                        /* Throws exception if it dosent end in .java */
                        throw new NotJavaException(name);
                        }
                    }
                    /* Prints file name to output file */
                    catch(NotJavaException newFile){
                    outFile.println(newFile.getMessage());
                    }
            }
            /* Closes the output file and gives closing message to user*/
            outFile.close();
            System.out.println("Program Complete, Please see " + outputFile); 
            } 

            /*Display exception message*/
            catch(FileNotFoundException newFile) {
            System.out.println(newFile.getMessage());;
            }
    }
}
